Pagina da Cafeteria DNC

- Construida com Bootstrap
- Modal aparece clicando no sobre
- Imagens com comportamento responsívo
